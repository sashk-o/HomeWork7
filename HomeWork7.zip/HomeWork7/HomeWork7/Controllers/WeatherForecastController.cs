﻿using HomeWork7.Filters;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HomeWork7.Controllers
{
    [ApiController]
    [Route("[controller]")]

    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
            "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
        };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpGet]
        [Route("Get/{id}")]
        [TypeFilter(typeof(MyActionFilter))]
        [TypeFilter(typeof(MyExceptionFilter))]
        public IActionResult Get(int id)
        {
            string str = string.Format($"Результат ділення числа 10 на {id}: {10 / id}");
            return Ok(str);
        }
    }
}
