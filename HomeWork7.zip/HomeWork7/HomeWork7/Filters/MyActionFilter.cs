﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Primitives;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HomeWork7.Filters
{
    public class MyActionFilter : Attribute, IActionFilter
    {
        private readonly IConfiguration configuration;
        public MyActionFilter(IConfiguration configuration)
        {
            this.configuration = configuration;
        }
        public void OnActionExecuted(ActionExecutedContext context)
        {
            
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            var arg1key = configuration["Validation:arg1key"];
            var arg2key = configuration["Validation:arg2key"];
            var reskey = configuration["Validation:MathAddResult"];

            var arg1 = context.HttpContext.Request.Cookies.TryGetValue(arg1key, out var t1) ? t1 : "0";
            var arg2 = context.HttpContext.Request.Cookies.TryGetValue(arg2key, out var t2) ? t2 : "0";

            var a = int.TryParse(arg1, out var g1) ? g1 : 0;
            var b = int.TryParse(arg2, out var g2) ? g2 : 0;

            var headerArg = context.HttpContext.Request.Headers.TryGetValue(reskey, out var res) ? res : new StringValues();
            var c = int.TryParse(headerArg.FirstOrDefault(), out var c1) ? c1 : 0;

            if (a + b != c)
            {
                context.Result = new ContentResult { Content = $"Некоректний запит! Результат додавання {arg1key} + {arg2key} повинен дорівнювати {res}!" };
            }
        }
    }
}
