﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace HomeWork7.Filters
{
    public class MyExceptionFilter : Attribute, IExceptionFilter
    {
        private readonly ILogger<MyExceptionFilter> logger;
        public MyExceptionFilter(ILogger<MyExceptionFilter> logger)
        {
            this.logger = logger;
        }
        public void OnException(ExceptionContext context)
        {
            var message = string.Empty;
            if (context.Exception is DivideByZeroException)
            {
                message = "Запит не може бути оброблено!";
            }
            else
            {
                message = $"Виникла помилка! {context.Exception.Message}";
            }
            context.Result = new ContentResult { Content = message };
            logger.LogInformation("Exception: "+ context.Exception.Message + "\n");
            context.ExceptionHandled = true;
        }
    }
}
